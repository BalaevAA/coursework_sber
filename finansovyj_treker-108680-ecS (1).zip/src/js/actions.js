function add_transaction(text, price, context) {
        addAction({
            type: "add_transaction",
            text: text,
            price: price
        }, context);
}

function delete_transaction(number, context) {
    addAction({
        type: "delete_transaction",
        number: number
    }, context);
}

function checkLength(number, context) {
    var items = get_items(get_request(context));
    if (items[2].length < Number(number)) {
        return false;
    }
    return true;
}